<?php
/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $number
 * @var $icon_class
 * @var $parallax_value
 * @var $content - shortcode content
 *
 * Shortcode class
 * @var $this WPBakeryShortCode_Monolit_Breadcrumb
 */
// $el_class = $css = '';
// $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
// extract( $atts );

monolit_breadcrumbs();
